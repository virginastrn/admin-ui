export const expenseService = async () => {
  try {
    const token = localStorage.getItem("token");

    const response = await axios.get(`${API_URL}/expenses`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    // Cek di console DevTools bentuk data asli dari API,
    // sesuaikan mapping field di CardExpensesComparison.jsx kalau beda.
    console.log("Response /expenses:", response.data);

    return response.data.data;
  } catch (error) {
    throw {
      status: error.response?.status,
      msg: error.response?.data?.msg,
    };
  }
};