import React from "react";
import Icon from "./Icon";

// Pemetaan nama kategori -> icon, dipakai kalau data dari backend
// tidak mengirim icon-nya sendiri (backend biasanya cuma kirim nama kategori).
const categoryIconMap = {
  housing: <Icon.House />,
  food: <Icon.Food />,
  transportation: <Icon.Transport />,
  transport: <Icon.Transport />,
  entertainment: <Icon.Gamepad />,
  shopping: <Icon.Shopping />,
  others: <Icon.Other />,
  other: <Icon.Other />,
};

function getCategoryIcon(category) {
  const key = (category || "").toLowerCase();
  return categoryIconMap[key] || <Icon.Other />;
}

/**
 * CardExpense - "element card baru" untuk menampilkan satu kategori
 * pengeluaran beserta rincian transaksinya (mengikuti desain FINEbank.io).
 *
 * Props:
 * - category   : nama kategori, contoh "Housing"
 * - amount     : total pengeluaran kategori ini, contoh 250
 * - percentage : angka persen perubahan, contoh 15
 * - trend      : "up" | "down" (naik/turun dibanding bulan lalu)
 * - items      : array rincian transaksi [{ id, name, date, amount }]
 * - icon       : (opsional) override icon, kalau tidak diisi akan otomatis
 *                dipilih berdasarkan nama kategori
 */
function CardExpense({ category, amount, percentage, trend = "down", items = [], icon }) {
  const isUp = trend === "up";

  return (
    <div className="bg-white rounded-lg px-6 py-5 shadow-xl">
      {/* Header kategori */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <div className="bg-special-bg text-gray-02 p-2 rounded-lg flex items-center justify-center me-3">
            {icon || getCategoryIcon(category)}
          </div>
          <div>
            <div className="font-bold">{category}</div>
            <div className="text-gray-03 text-xs flex items-center gap-1">
              {percentage}% {isUp ? <Icon.ArrowUp size={12} /> : <Icon.ArrowDown size={12} />}
              <span className="ms-1">Compare to the last month</span>
            </div>
          </div>
        </div>
        <div className="font-bold text-lg whitespace-nowrap ms-2">${amount}</div>
      </div>

      <div className="border-b border-gray-05 mb-3"></div>

      {/* Rincian transaksi per kategori */}
      <div className="flex flex-col gap-3">
        {items.length === 0 && (
          <div className="text-gray-03 text-sm">Belum ada transaksi</div>
        )}
        {items.map((item, idx) => (
          <div key={item.id ?? idx} className="flex justify-between text-sm">
            <div>
              <div className="text-gray-02">{item.name}</div>
              <div className="text-gray-03 text-xs">{item.date}</div>
            </div>
            <div className="font-bold">${item.amount}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CardExpense;